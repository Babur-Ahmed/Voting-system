##from distutils.core import setup
##import py2exe
##
##setup(windows = ['voting.py'])

from distutils.core import setup
import py2exe

data_files = [('', [r'backgrounds', 'sample.jpg'])]

setup(
windows =['voting.py'],
data_files = data_files,
options={
         }
)
